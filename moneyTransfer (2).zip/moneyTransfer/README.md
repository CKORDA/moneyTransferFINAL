# MoneyTransfer----Midterm
Collaborators:
Ramatoulaye Signate
Davd-Michael Davies
Cheyenne Korda
